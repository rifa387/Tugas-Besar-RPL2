<?php
defined('BASEPATH') or exit('No direct script access allowed');

class model_dataKost extends CI_Model
{

    public function tampilDataKost()
    {
        return $this->db->get('tb_kost')->result_array();
    }

    public function tambahDataKost()
    {
        $nama_kost = $this->input->post('nm_kost', true);
        $alamat = $this->input->post('alamat', true);
        $no_tlp = $this->input->post('notlp', true);
        $harga = $this->input->post('harga', true);

        $uploads = $_FILES['upload']['name'];
        $uploads1 = $_FILES['upload']['tmp_name'];
        $dirUpload = "./assets/img";
        move_uploaded_file($uploads1, $dirUpload . $uploads);




        $data = [
            'nama_kost' => $nama_kost,
            'alamat' => $alamat,
            'no_telpon' => $no_tlp,
            'harga' => $harga,
            'gambar' => $uploads
        ];

        $this->db->insert('tb_kost', $data);
    }

    public function getKostByid($id)
    {
        return $this->db->get_where('tb_kost', ['id' => $id])->row_array();
    }

    public function ubahDataKost()
    {
        $data = [
            'nama' => $this->input->post('nm_kost', true),
            'alamat' => $this->input->post('alamat', true),
            'no_telpon' => $this->input->post('notlp', true),
            'harga' => $this->input->post('harga', true),
            'gambar' => $this->input->post('upload', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('tb_kost', $data);
    }

    public function cariDataKost()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('nama_kost', $keyword);

        return $this->db->get('tb_kost')->result_array();
    }
}
