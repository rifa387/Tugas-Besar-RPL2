<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{


    public function __construct()
    {
        parent::__construct();
        $this->load->model('Model_dataKost');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = 'Tampilan Utama';
        $data['kost'] = $this->Model_dataKost->tampilDataKost();
        if ($this->input->post('keyword')) {
            $data['kost'] = $this->Model_dataKost->cariDataKost();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('nm_kost', 'NamaKost', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('notlp', 'NoTlp', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required');
        $data['title'] = 'Form tambah data';
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('admin/tambah');
            $this->load->view('templates/footer');
        } else {
            $this->model_dataKost->tambahDataKost();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Data berhasil disimpan
          </div>');
            redirect('Admin');
        }
    }

    public function hapus($id)
    {
        $this->db->delete('tb_kost', ['id' => $id]);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
        Data berhasil dihapus
      </div>');
        redirect('Admin');
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('nm_kost', 'NamaKost', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('notlp', 'NoTlp', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required');
        $this->form_validation->set_rules('upload', 'Upload', 'required');

        $data['title'] = 'Ubah Data';
        $data['ubahData'] = $this->Model_dataKost->getKostByid($id);
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('admin/ubah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->model_dataKost->ubahDataKost();
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
        Data berhasil diubah
      </div>');
            redirect('Admin');
        }
    }
}
