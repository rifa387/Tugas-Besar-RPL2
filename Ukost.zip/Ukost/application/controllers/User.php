<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Model_dataKost');
        $this->load->library('form_validation');
    }

    public function index()
    {

        $data['title'] = 'Tampilan Utama';
        $data['kost'] = $this->Model_dataKost->tampilDataKost();
        if ($this->input->post('keyword')) {
            $data['kost'] = $this->Model_dataKost->cariDataKost();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');
    }
}
