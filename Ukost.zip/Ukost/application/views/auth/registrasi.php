<div class="row">
    <div class="col">
        <img src="<?= base_url('assets/img/logo.png'); ?>" width="200px" height="100px">
    </div>
</div>

<div class="kotak">
    <div class="tulisan text-center">
        <h3>Registrasi</h3>
    </div>
    <form action="<?= base_url('auth/registrasi'); ?>" method="post">
        <div class="form-group">
            <input type="text" class="form-control" name="namaR" placeholder="Nama" value="<?= set_value('namaR'); ?>">
            <?= form_error('namaR', '<small class="text-danger">', '</small>'); ?>
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="emailR" placeholder="Email" value="<?= set_value('emailR'); ?>">
            <?= form_error('emailR', '<small class="text-danger">', '</small>'); ?>
        </div>
        <div class="form-group">
            <input type="password" class="form-control" name="passwordR" placeholder="Password">
            <?= form_error('passwordR', '<small class="text-danger">', '</small>'); ?>
        </div>
        <center>
            <button type="submit" class="btn btn-success tombol-login">Buat</button>
            <a href="" class="btn btn-danger tombol-login">Reset</a>
        </center>
        <br>
        <br>
        <a href="<?= base_url("auth"); ?>">Kembali</a>
    </form>
</div>