<div class="row">
    <div class="col-md-9">
        <img src="<?= base_url('assets/img/logo.png'); ?>" width="200px" height="100px">
    </div>

    <div class="col-md-3">
        <div class="row">
            <div class="col ls">
                <a href="<?= base_url('auth/login'); ?>" class="btn btn-success">Login</a>
                <a href="<?= base_url('auth/registrasi'); ?>" class="btn btn-success">Sign Up</a>
            </div>
        </div>
        <div class="row">
            <div class="col search">
                <form action="" class="form-inline" method="POST">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="keyword">
                    <button class="btn btn-success" type="submit">Search</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <h3>Rekomendasi Kost di bandung</h3>
    <div class="row">
        <?php
        foreach ($kost as $row) {
        ?>
            <div class="col-md-3">
                <div class="card">
                    <img src="<?= base_url('assets/img'); ?>/<?= $row['gambar']; ?>" width="200px" height="150px" class="ml-4 mt-4">
                    <div class="card-body">
                        <h5 class="card-title"><?= $row['nama_kost']; ?></h5>
                        <p class="card-text">Alamat : <?= $row['alamat']; ?></p>
                        <p class="card-text">No Telpon : <?= $row['no_telpon']; ?></p>
                        <p class="card-text">Harga/bulan : <?= $row['harga']; ?></p>
                    </div>
                </div>
            </div>


        <?php
        }
        ?>

    </div>
    <h3 class="mt-5">Statistik Pengunjung</h3>

    <table id="foot-table-list">
        <tr>

            <td>Pengunjung Hari ini</td>

            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>

            <td><?php echo $pengunjunghariini ?> orang</td>

        </tr>

        <tr>

            <td>Total Pengunjung</td>

            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>

            <td><?php echo $totalpengunjung ?> orang</td>

        </tr>

        <tr>

            <td>Pengunjung Online</td>

            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>

            <td><?php echo $pengunjungonline ?> orang</td>

        </tr>

    </table>
</div>