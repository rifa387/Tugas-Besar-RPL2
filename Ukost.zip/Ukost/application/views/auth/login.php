<div class="row">
    <div class="col">
        <img src="<?= base_url('assets/img/logo.png'); ?>" width="200px" height="100px">
    </div>
</div>

<div class="kotak">
    <div class="tulisan text-center">
        <h3>Login</h3>
        <?= $this->session->flashdata('message'); ?>
    </div>
    <form action="" method="post">
        <div class="form-group">
            <input type="text" class="form-control" name="email" placeholder="Email" value="<?= set_value('email'); ?>">
            <?= form_error('email', '<small class="text-danger">', '</small>'); ?>
        </div>
        <div class="form-group">
            <input type="password" class="form-control" name="password" placeholder="Password">
            <?= form_error('password', '<small class="text-danger">', '</small>'); ?>
        </div>
        <center>
            <button type="submit" class="btn btn-success tombol-login w-25">Login</button>
            <a href="" class="btn btn-danger tombol-login">Reset</a>
        </center>

        <br>
        <br>
        <a href="<?= base_url("auth"); ?>">Kembali</a>
    </form>
</div>