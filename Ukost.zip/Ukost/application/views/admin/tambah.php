<div class="container">
    <div class="content w-25 m-auto">
        <h2>Tambah Data Kost</h2>
        <?= form_open_multipart('Admin/tambah'); ?>
        <div class="form-group">
            <label for="nm_kost">Nama kost</label>
            <input type="text" class="form-control" name="nm_kost">
        </div>
        <div class="form-group">
            <label for="alamat">Alamat</label>
            <input type="text" class="form-control" name="alamat">
        </div>
        <div class="form-group">
            <label for="notlp">No Telpon</label>
            <input type="number" class="form-control" name="notlp">
        </div>
        <div class="form-group">
            <label for="harga">Harga Perbulan</label>
            <input type="number" class="form-control" name="harga">
        </div>
        <div class="form-group">
            <label for="upload">Upload gambar</label>
            <input type="file" name="upload">
        </div>
        <button type="submit" class="btn btn-success">Tambah</button>
        <?= form_close(); ?>
    </div>
</div>