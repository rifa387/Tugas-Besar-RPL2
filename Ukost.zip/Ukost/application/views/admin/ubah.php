<div class="container">
    <div class="content w-25 m-auto">
        <h2>Ubah Data Kost</h2>
        <form action="<?= base_url('Admin/ubah'); ?>" method="post" class="mt-4">
            <input type="hidden" name="id" value="<?= $ubahData['id']; ?>">
            <div class="form-group">
                <label for="nm_kost">Nama kost</label>
                <input type="text" class="form-control" name="nm_kost" value="<?= $ubahData['nama_kost']; ?>">
            </div>
            <div class="form-group">
                <label for="alamat">Alamat</label>
                <input type="text" class="form-control" name="alamat" value="<?= $ubahData['alamat']; ?>">
            </div>
            <div class="form-group">
                <label for="notlp">No Telpon</label>
                <input type="number" class="form-control" name="notlp" value="<?= $ubahData['no_telpon']; ?>">
            </div>
            <div class="form-group">
                <label for="harga">Harga Perbulan</label>
                <input type="number" class="form-control" name="harga" value="<?= $ubahData['harga']; ?>">
            </div>
            <div class="form-group">
                <label for="upload">Upload gambar</label>
                <input type="file" name="upload" value="<?= $ubahData['gambar']; ?>
                ">
            </div>
            <button type="submit" class="btn btn-success">Ubah</button>
        </form>
    </div>
</div>