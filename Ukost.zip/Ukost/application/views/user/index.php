<div class="row">
    <div class="col-md-9">
        <img src="<?= base_url('assets/img/logo.png'); ?>" width="200px" height="100px">
    </div>

    <div class="col-md-3">
        <div class="row logout">
            <a href="<?= base_url('auth/logout'); ?>" class="btn btn-success">Logout</a>
        </div>
        <div class="row">
            <div class="col search">
                <form action="" class="form-inline" method="POST">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="keyword">
                    <button class="btn btn-success" type="submit">Search</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <h3>Rekomendasi Kost di bandung</h3>
    <?= $this->session->flashdata('message'); ?>
    <div class="row mt-4">
        <?php
        foreach ($kost as $row) {
        ?>
            <div class="col-md-3">
                <div class="card">
                    <img src="<?= base_url('assets/img'); ?>/<?= $row['gambar']; ?>" width="250" height="200">
                    <div class="card-body">
                        <h5 class="card-title"><?= $row['nama_kost']; ?></h5>
                        <p class="card-text">Alamat : <?= $row['alamat']; ?></p>
                        <p class="card-text">No telpon : <?= $row['no_telpon']; ?></p>
                        <p class="card-text">Harga/bulan : <?= $row['harga']; ?></p>
                        <a href="#" class="btn btn-success ml-4">Share to whatsapp</a>
                    </div>
                </div>
            </div>


        <?php
        }
        ?>

    </div>

</div>